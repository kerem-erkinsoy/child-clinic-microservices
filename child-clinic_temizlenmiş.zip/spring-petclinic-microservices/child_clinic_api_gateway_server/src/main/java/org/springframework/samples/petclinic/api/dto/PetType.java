package org.springframework.samples.petclinic.api.dto;

import lombok.Data;


@Data
public class PetType {

    private String name;
}
