INSERT INTO visits VALUES (1, 7, '2013-01-01', 'rabies shot', 'Dr. Erhan Gültekin');
INSERT INTO visits VALUES (2, 8, '2013-01-02', 'rabies shot', 'Dr. Erhan Gültekin');
INSERT INTO visits VALUES (3, 8, '2013-01-03', 'neutered', 'Dr. Erhan Gültekin');
INSERT INTO visits VALUES (4, 7, '2013-01-04', 'spayed', 'Dr. Erhan Gültekin');
